1. Move the content of the archive to the root of the serving directory
2. Make certain that *assets* folder is at the root of the serving directory
3. *template.html* should be sufficiently annotated to navigate and to add
content.  Sections of interests are Navigation and Body.  Section marked with
[TEXT] (use CTRL+F) is where the content of the page should be added to.
